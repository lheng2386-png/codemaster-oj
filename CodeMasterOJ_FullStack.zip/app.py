# -*- coding: utf-8 -*-
"""CodeMaster OJ - 完整后端服务"""
import os, json, sys
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from models import db, User, Problem, Submission, Contest, Comment
from judge import judge_python, test_code

app = Flask(__name__, template_folder='templates', static_folder='static')
app.secret_key = os.urandom(24).hex()
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///oj_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# ========== 默认题目数据 ==========
DEFAULT_PROBLEMS = [
    dict(title="A+B Problem", difficulty="入门", category="输入输出", tags=["基础","输入输出"],
        description="给定两个整数 A 和 B，输出 A+B 的值。\n\n**输入格式**\n一行两个整数 A B（-1000 ≤ A,B ≤ 1000）\n\n**输出格式**\n一个整数\n\n**样例**\n输入: 3 5\n输出: 8",
        template="a, b = map(int, input().split())\n# 在此填写代码\n",
        solution="a, b = map(int, input().split())\nprint(a + b)",
        hint="直接用 input().split() 读取两个数，相加后 print 即可。",
        cases=[["3 5","8"],["0 0","0"],["-5 3","-2"],["100 200","300"]], points=10),
    dict(title="Hello World", difficulty="入门", category="输入输出", tags=["基础","输出"],
        description="输出一行 Hello, World!\n\n**输入格式**\n无\n\n**输出格式**\nHello, World!",
        template="# 输出 Hello, World!\n", solution="print('Hello, World!')",
        hint="直接 print('Hello, World!') 注意标点是英文。",
        cases=[["","Hello, World!"]], points=5),
    dict(title="判断奇偶数", difficulty="入门", category="条件判断", tags=["条件","取余"],
        description="给定整数 N，判断是奇数还是偶数。\n\n**输入格式**\n一个整数 N\n\n**输出格式**\n奇数输出 odd，偶数输出 even\n\n**样例**\n输入: 4\n输出: even",
        template="n = int(input())\n# 判断奇偶\n", solution="n = int(input())\nprint('odd' if n % 2 != 0 else 'even')",
        hint="用 n % 2 判断余数。", cases=[["4","even"],["7","odd"],["0","even"],["-3","odd"]], points=10),
    dict(title="三数最大值", difficulty="入门", category="条件判断", tags=["max","条件"],
        description="给定三个整数，输出最大值。\n\n**输入格式**\n一行三个整数\n\n**输出格式**\n最大值\n\n**样例**\n输入: 3 1 4\n输出: 4",
        template="a, b, c = map(int, input().split())\n# 输出最大值\n", solution="a, b, c = map(int, input().split())\nprint(max(a, b, c))",
        hint="可以用 max() 内置函数。", cases=[["3 1 4","4"],["0 0 0","0"],["-1 -2 -3","-1"]], points=10),
    dict(title="字符串反转", difficulty="入门", category="字符串", tags=["字符串","切片"],
        description="给定一个字符串，反转后输出。\n\n**输入格式**\n一行字符串（长度 ≤ 100）\n\n**输出格式**\n反转后的字符串\n\n**样例**\n输入: hello\n输出: olleh",
        template="s = input()\n# 反转字符串\n", solution="print(input()[::-1])",
        hint="Python 切片 s[::-1] 可以直接反转。", cases=[["hello","olleh"],["abc","cba"],["a","a"]], points=10),
    dict(title="求阶乘", difficulty="简单", category="循环", tags=["循环","阶乘"],
        description="给定整数 N，计算 N! 的值。\n\n**输入格式**\n一个整数 N（0 ≤ N ≤ 12）\n\n**输出格式**\nN! 的值\n\n**样例**\n输入: 5\n输出: 120",
        template="n = int(input())\nresult = 1\n# 用循环计算阶乘\nprint(result)\n", solution="n = int(input())\nr = 1\nfor i in range(1, n+1): r *= i\nprint(r)",
        hint="从1循环到n，每次乘以循环变量。", cases=[["5","120"],["0","1"],["1","1"],["10","3628800"]], points=20),
    dict(title="斐波那契数列", difficulty="简单", category="循环", tags=["数列","循环"],
        description="输出斐波那契数列第 N 项（F(1)=1, F(2)=1）。\n\n**输入格式**\n一个整数 N（1 ≤ N ≤ 30）\n\n**输出格式**\n第 N 项的值\n\n**样例**\n输入: 7\n输出: 13",
        template="n = int(input())\n# 计算第n项斐波那契数\n", solution="n=int(input())\na,b=1,1\nfor _ in range(n-2):a,b=b,a+b\nprint(a if n<=2 else b)",
        hint="维护前两项 a, b，每次 a,b = b, a+b。", cases=[["1","1"],["2","1"],["7","13"],["10","55"]], points=20),
    dict(title="简单计算器", difficulty="简单", category="运算", tags=["运算符","条件"],
        description="实现加减乘除四则运算。\n\n**输入格式**\n格式：a op b（op 为 +,-,*,/）\n\n**输出格式**\n结果（除法保留2位小数）\n\n**样例**\n输入: 10 / 3\n输出: 3.33",
        template="parts = input().split()\na, op, b = int(parts[0]), parts[1], int(parts[2])\n# 实现四则运算\n",
        solution="p=input().split()\na,op,b=int(p[0]),p[1],int(p[2])\nif op=='+':print(a+b)\nelif op=='-':print(a-b)\nelif op=='*':print(a*b)\nelse:print(f'{a/b:.2f}')",
        hint="用 if-elif 判断运算符。", cases=[["10 / 3","3.33"],["3 + 5","8"],["10 - 4","6"],["3 * 7","21"]], points=15),
    dict(title="冒泡排序", difficulty="中等", category="排序", tags=["排序","数组"],
        description="实现冒泡排序，对 N 个整数从小到大排序。\n\n**输入格式**\n第一行 N（1 ≤ N ≤ 100）\n第二行 N 个整数\n\n**输出格式**\n排序后的序列（空格分隔）\n\n**样例**\n输入: 5\n3 1 4 1 5\n输出: 1 1 3 4 5",
        template="n = int(input())\nnums = list(map(int, input().split()))\n# 实现冒泡排序\nprint(*nums)\n",
        solution="n=int(input())\na=list(map(int,input().split()))\nfor i in range(n):\n  for j in range(n-i-1):\n    if a[j]>a[j+1]:a[j],a[j+1]=a[j+1],a[j]\nprint(*a)",
        hint="外层循环 n 次，内层比较相邻元素。", cases=[["5\n3 1 4 1 5","1 1 3 4 5"],["3\n3 2 1","1 2 3"]], points=30),
    dict(title="二分查找", difficulty="中等", category="查找", tags=["二分","有序数组"],
        description="在升序数组中查找目标值，返回下标（从0起），不存在返回 -1。\n\n**输入格式**\n第一行 N target\n第二行 N 个升序整数\n\n**输出格式**\n下标或 -1\n\n**样例**\n输入: 5 3\n1 2 3 4 5\n输出: 2",
        template="n, t = map(int, input().split())\nnums = list(map(int, input().split()))\n# 实现二分查找\n",
        solution="n,t=map(int,input().split())\na=list(map(int,input().split()))\nl,r=0,n-1\nans=-1\nwhile l<=r:\n  m=(l+r)//2\n  if a[m]==t:ans=m;break\n  elif a[m]<t:l=m+1\n  else:r=m-1\nprint(ans)",
        hint="维护 left, right，每次取中间 mid。", cases=[["5 3\n1 2 3 4 5","2"],["5 6\n1 2 3 4 5","-1"]], points=30),
    dict(title="质数判断", difficulty="中等", category="数论", tags=["质数","数论"],
        description="判断整数 N 是否为质数。\n\n**输入格式**\nN（2 ≤ N ≤ 10^6）\n\n**输出格式**\n质数输出 Yes，否则 No\n\n**样例**\n输入: 17\n输出: Yes",
        template="n = int(input())\n# 判断质数\n", solution="n=int(input())\nif n<2:print('No')\nelse:\n  ok=True\n  i=2\n  while i*i<=n:\n    if n%i==0:ok=False;break\n    i+=1\n  print('Yes'if ok else'No')",
        hint="只需枚举到 √n。", cases=[["17","Yes"],["4","No"],["2","Yes"],["1000000","No"]], points=30),
    dict(title="回文字符串", difficulty="中等", category="字符串", tags=["字符串","回文"],
        description="判断一个字符串是否为回文串（忽略大小写）。\n\n**输入格式**\n一行字符串\n\n**输出格式**\n是回文输出 Yes，否则 No\n\n**样例**\n输入: Racecar\n输出: Yes",
        template="s = input()\n# 判断回文\n", solution="s=input().lower()\nprint('Yes'if s==s[::-1]else'No')",
        hint="先 .lower() 转小写，再判断 s == s[::-1]。", cases=[["Racecar","Yes"],["hello","No"],["abba","Yes"]], points=25),
    dict(title="最大公约数", difficulty="中等", category="数论", tags=["GCD","辗转相除"],
        description="求两个正整数的最大公约数。\n\n**输入格式**\n两个正整数 a b\n\n**输出格式**\nGCD(a,b)\n\n**样例**\n输入: 12 8\n输出: 4",
        template="a, b = map(int, input().split())\n# 用辗转相除法求GCD\n", solution="a,b=map(int,input().split())\nwhile b:a,b=b,a%b\nprint(a)",
        hint="辗转相除：while b: a,b = b, a%b。", cases=[["12 8","4"],["100 75","25"],["7 13","1"]], points=25),
    dict(title="括号匹配", difficulty="中等", category="栈", tags=["栈","括号"],
        description="判断括号序列是否合法（包括 () [] {}）。\n\n**输入格式**\n一行由括号组成的字符串\n\n**输出格式**\n合法输出 Yes，否则 No\n\n**样例**\n输入: {[()]}\n输出: Yes",
        template="s = input()\n# 用栈判断括号合法性\n", solution="s=input()\nst=[]\nm={')':'(',']':'[','}':'{'}\nfor c in s:\n  if c in'([{':st.append(c)\n  elif st and st[-1]==m[c]:st.pop()\n  else:print('No');exit()\nprint('Yes'if not st else'No')",
        hint="用栈：遇左括号入栈，遇右括号检查栈顶。", cases=[["{[()]}","Yes"],["([)]","No"],["","Yes"],["((()))","Yes"]], points=30),
    dict(title="最长公共子序列", difficulty="困难", category="动态规划", tags=["DP","LCS"],
        description="求两个字符串的最长公共子序列（LCS）长度。\n\n**输入格式**\n两行字符串（长度 ≤ 100）\n\n**输出格式**\nLCS 长度\n\n**样例**\n输入: ABCDE\nACE\n输出: 3",
        template="s1 = input()\ns2 = input()\n# 实现 LCS 动态规划\n",
        solution="s1=input();s2=input()\nm,n=len(s1),len(s2)\ndp=[[0]*(n+1)for _ in range(m+1)]\nfor i in range(1,m+1):\n  for j in range(1,n+1):\n    dp[i][j]=dp[i-1][j-1]+1 if s1[i-1]==s2[j-1]else max(dp[i-1][j],dp[i][j-1])\nprint(dp[m][n])",
        hint="dp[i][j] 表示 LCS 长度，相等则+1，否则取上/左最大值。", cases=[["ABCDE\nACE","3"],["ABC\nABC","3"],["ABC\nDEF","0"]], points=50),
    dict(title="背包问题", difficulty="困难", category="动态规划", tags=["DP","背包"],
        description="0/1背包：N 个物品，背包容量 W，求最大价值。\n\n**输入格式**\n第一行 N W\n接下来 N 行每行 w[i] v[i]\n\n**输出格式**\n最大价值\n\n**样例**\n输入: 4 10\n2 6\n2 3\n6 5\n5 4\n输出: 9",
        template="n, W = map(int, input().split())\nitems = [tuple(map(int,input().split())) for _ in range(n)]\n# 实现0/1背包DP\n",
        solution="n,W=map(int,input().split())\nitems=[tuple(map(int,input().split()))for _ in range(n)]\ndp=[0]*(W+1)\nfor w,v in items:\n  for j in range(W,w-1,-1):dp[j]=max(dp[j],dp[j-w]+v)\nprint(dp[W])",
        hint="一维DP，逆序遍历容量。", cases=[["4 10\n2 6\n2 3\n6 5\n5 4","9"],["3 5\n2 3\n3 4\n4 5","7"]], points=50),
    dict(title="快速幂", difficulty="困难", category="数论", tags=["快速幂","位运算"],
        description="计算 a^b mod p。\n\n**输入格式**\n三个整数 a b p\n\n**输出格式**\na^b mod p\n\n**样例**\n输入: 2 10 1000\n输出: 24",
        template="a, b, p = map(int, input().split())\n# 实现快速幂\n",
        solution="a,b,p=map(int,input().split())\nr=1;a%=p\nwhile b:\n  if b&1:r=r*a%p\n  a=a*a%p;b>>=1\nprint(r)",
        hint="将指数 b 用二进制分解。", cases=[["2 10 1000","24"],["3 3 7","6"],["2 0 1000","1"]], points=50),
    dict(title="图的BFS最短路", difficulty="困难", category="图论", tags=["BFS","图"],
        description="给定无权无向图，求从顶点1到顶点N的最短路径长度，不可达输出 -1。\n\n**输入格式**\n第一行 N M\n接下来 M 行，每行 u v\n\n**输出格式**\n最短路径边数，不可达输出 -1\n\n**样例**\n输入: 5 5\n1 2\n2 3\n3 5\n1 4\n4 5\n输出: 2",
        template="from collections import deque\nn, m = map(int, input().split())\ngraph = [[] for _ in range(n+1)]\nfor _ in range(m):\n    u, v = map(int, input().split())\n    graph[u].append(v)\n    graph[v].append(u)\n# 实现BFS求最短路\n",
        solution="from collections import deque\nn,m=map(int,input().split())\ng=[[]for _ in range(n+1)]\nfor _ in range(m):\n  u,v=map(int,input().split());g[u].append(v);g[v].append(u)\nd=[-1]*(n+1);d[1]=0\nq=deque([1])\nwhile q:\n  u=q.popleft()\n  for v in g[u]:\n    if d[v]==-1:d[v]=d[u]+1;q.append(v)\nprint(d[n])",
        hint="BFS 逐层扩展，d[v] = d[u]+1。", cases=[["5 5\n1 2\n2 3\n3 5\n1 4\n4 5","2"],["4 2\n1 2\n3 4","-1"]], points=60),
]

# ========== 辅助函数 ==========
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        user = User.query.get(session['user_id'])
        if not user or user.role != 'admin':
            flash('需要管理员权限', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

def now_str():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

# ========== 初始化 ==========
def init_data():
    """首次启动时初始化数据库"""
    db.create_all()
    if User.query.filter_by(username='admin').first() is None:
        admin = User(username='admin', nickname='管理员', role='admin', points=0, created_at=now_str())
        admin.set_password('admin123')
        db.session.add(admin)
    if Problem.query.count() == 0:
        for i, pd in enumerate(DEFAULT_PROBLEMS, 1):
            p = Problem(
                title=pd['title'], difficulty=pd['difficulty'], category=pd['category'],
                tags=json.dumps(pd['tags']), description=pd['description'],
                template=pd['template'], solution=pd['solution'], hint=pd['hint'],
                cases_json=json.dumps(pd['cases']), points=pd['points'],
                created_at=now_str()
            )
            db.session.add(p)
    db.session.commit()

# ========== 页面路由 ==========
@app.route('/')
@login_required
def index():
    user = User.query.get(session['user_id'])
    problems = Problem.query.filter_by(is_public=True).all()
    solved_ids = set(s.problem_id for s in Submission.query.filter_by(user_id=user.id, status='AC').all())
    recent = Submission.query.filter_by(user_id=user.id).order_by(Submission.id.desc()).limit(8).all()
    return render_template('index.html', user=user, problems=problems, solved_ids=solved_ids, recent=recent)

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        u = request.form.get('username','').strip()
        p = request.form.get('password','')
        user = User.query.filter_by(username=u).first()
        if user and user.check_password(p):
            if not user.is_active:
                flash('账号已被禁用，请联系管理员', 'error')
                return redirect(url_for('login'))
            session['user_id'] = user.id
            user.last_active = now_str()
            db.session.commit()
            return redirect(url_for('index'))
        flash('用户名或密码错误', 'error')
    return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        u = request.form.get('username','').strip()
        p = request.form.get('password','')
        p2 = request.form.get('password2','')
        nk = request.form.get('nickname','').strip()
        if not u or not p:
            flash('请填写完整信息', 'error'); return redirect(url_for('register'))
        if p != p2:
            flash('两次密码不一致', 'error'); return redirect(url_for('register'))
        if len(u) < 3 or len(p) < 4:
            flash('用户名至少3位，密码至少4位', 'error'); return redirect(url_for('register'))
        if User.query.filter_by(username=u).first():
            flash('用户名已存在', 'error'); return redirect(url_for('register'))
        user = User(username=u, nickname=nk or u, role='student', created_at=now_str())
        user.set_password(p)
        db.session.add(user)
        db.session.commit()
        flash('注册成功，请登录', 'success')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# ========== 题库 ==========
@app.route('/problems')
@login_required
def problems():
    user = User.query.get(session['user_id'])
    diff = request.args.get('difficulty', '全部')
    cat = request.args.get('category', '全部')
    kw = request.args.get('keyword', '')
    q = Problem.query.filter_by(is_public=True)
    if diff != '全部': q = q.filter_by(difficulty=diff)
    if cat != '全部': q = q.filter_by(category=cat)
    if kw: q = q.filter(Problem.title.contains(kw))
    probs = q.order_by(Problem.id).all()
    solved_ids = set(s.problem_id for s in Submission.query.filter_by(user_id=user.id, status='AC').all())
    categories = sorted(set(p.category for p in Problem.query.filter_by(is_public=True).all()))
    return render_template('problems.html', user=user, problems=probs, solved_ids=solved_ids,
                          diff=diff, cat=cat, kw=kw, categories=categories)

@app.route('/problem/<int:pid>')
@login_required
def problem_detail(pid):
    user = User.query.get(session['user_id'])
    p = Problem.query.get_or_404(pid)
    comments = Comment.query.filter_by(problem_id=pid).order_by(Comment.id.desc()).all()
    user_comments = []
    for c in comments:
        cu = User.query.get(c.user_id)
        user_comments.append(c.to_dict(username=cu.nickname if cu else '未知'))
    my_sub = Submission.query.filter_by(user_id=user.id, problem_id=pid, status='AC').first()
    return render_template('problem.html', user=user, problem=p, comments=user_comments, solved=my_sub is not None)

# ========== 判题 API ==========
@app.route('/api/submit', methods=['POST'])
@login_required
def submit_code():
    user = User.query.get(session['user_id'])
    pid = int(request.form.get('problem_id', 0))
    code = request.form.get('code', '')
    p = Problem.query.get_or_404(pid)
    if not code.strip():
        return jsonify({'ok': False, 'msg': '代码不能为空'})

    cases = p.cases
    result = judge_python(code, cases, p.time_limit)
    status = 'AC' if result['passed'] == result['total'] else (result['results'][0]['status'] if result['results'] else 'RE')

    sub = Submission(user_id=user.id, problem_id=pid, code=code, status=status,
                     passed=result['passed'], total=result['total'],
                     details=json.dumps(result['results'], ensure_ascii=False), created_at=now_str())
    db.session.add(sub)
    p.submit_count += 1

    if status == 'AC':
        already = Submission.query.filter_by(user_id=user.id, problem_id=pid, status='AC').count()
        if already <= 1:  # 首次AC
            user.solved_count += 1
            user.points += p.points
            p.ac_count += 1
    user.submit_count += 1
    user.last_active = now_str()
    db.session.commit()

    return jsonify({'ok': True, 'status': status, 'passed': result['passed'], 'total': result['total'],
                    'results': result['results'], 'points': p.points if status == 'AC' and already <= 1 else 0})

@app.route('/api/run', methods=['POST'])
@login_required
def run_code():
    code = request.form.get('code', '')
    inp = request.form.get('input', '')
    if not code.strip():
        return jsonify({'ok': False, 'msg': '代码不能为空'})
    r = test_code(code, inp)
    return jsonify({'ok': True, 'stdout': r['stdout'], 'stderr': r['stderr']})

# ========== 评论 ==========
@app.route('/api/comment', methods=['POST'])
@login_required
def add_comment():
    pid = int(request.form.get('problem_id', 0))
    content = request.form.get('content', '').strip()
    if not content or len(content) > 1000:
        return jsonify({'ok': False, 'msg': '评论内容无效（1-1000字）'})
    if len(content) < 1:
        return jsonify({'ok': False, 'msg': '评论不能为空'})
    c = Comment(user_id=session['user_id'], problem_id=pid, content=content, created_at=now_str())
    db.session.add(c)
    db.session.commit()
    user = User.query.get(session['user_id'])
    return jsonify({'ok': True, 'comment': c.to_dict(username=user.nickname or user.username)})

@app.route('/api/comment/delete/<int:cid>', methods=['POST'])
@login_required
def delete_comment(cid):
    c = Comment.query.get_or_404(cid)
    user = User.query.get(session['user_id'])
    if user.role != 'admin' and c.user_id != user.id:
        return jsonify({'ok': False, 'msg': '无权删除'})
    db.session.delete(c)
    db.session.commit()
    return jsonify({'ok': True})

# ========== 排行榜 ==========
@app.route('/ranking')
@login_required
def ranking():
    user = User.query.get(session['user_id'])
    users = User.query.filter_by(is_active=True).order_by(User.points.desc(), User.solved_count.desc()).all()
    return render_template('ranking.html', user=user, users=users)

# ========== 比赛 ==========
@app.route('/contests')
@login_required
def contests():
    user = User.query.get(session['user_id'])
    all_contests = Contest.query.order_by(Contest.id.desc()).all()
    return render_template('contest.html', user=user, contests=all_contests)

@app.route('/contest/<int:cid>')
@login_required
def contest_detail(cid):
    user = User.query.get(session['user_id'])
    c = Contest.query.get_or_404(cid)
    probs = Problem.query.filter(Problem.id.in_(c.problem_ids)).all()
    solved_ids = set(s.problem_id for s in Submission.query.filter_by(user_id=user.id, status='AC').all())
    return render_template('contest_detail.html', user=user, contest=c, problems=probs, solved_ids=solved_ids)

# ========== 管理员 ==========
@app.route('/admin')
@admin_required
def admin_panel():
    user = User.query.get(session['user_id'])
    return render_template('admin.html', user=user, active_tab='overview')

@app.route('/admin/problems')
@admin_required
def admin_problems():
    user = User.query.get(session['user_id'])
    problems = Problem.query.order_by(Problem.id.desc()).all()
    return render_template('admin.html', user=user, active_tab='problems', problems=problems)

@app.route('/admin/users')
@admin_required
def admin_users():
    user = User.query.get(session['user_id'])
    users = User.query.order_by(User.id).all()
    return render_template('admin.html', user=user, active_tab='users', all_users=users)

@app.route('/admin/contests')
@admin_required
def admin_contests():
    user = User.query.get(session['user_id'])
    contests = Contest.query.order_by(Contest.id.desc()).all()
    return render_template('admin.html', user=user, active_tab='contests', all_contests=contests)

# 管理员 API
@app.route('/admin/api/problem/add', methods=['POST'])
@admin_required
def admin_add_problem():
    data = request.get_json() or {}
    if not data.get('title') or not data.get('cases'):
        return jsonify({'ok': False, 'msg': '题目标题和测试用例不能为空'})
    cases = []
    for c in data['cases']:
        if c.get('input') is not None and c.get('output') is not None:
            cases.append([c['input'], c['output']])
    p = Problem(
        title=data['title'], difficulty=data.get('difficulty','入门'), category=data.get('category','基础'),
        tags=json.dumps(data.get('tags',[])), description=data.get('description',''),
        template=data.get('template',''), solution=data.get('solution',''), hint=data.get('hint',''),
        cases_json=json.dumps(cases), points=int(data.get('points',10)),
        time_limit=int(data.get('time_limit',5)),
        author_id=session['user_id'], created_at=now_str()
    )
    db.session.add(p)
    db.session.commit()
    return jsonify({'ok': True, 'id': p.id})

@app.route('/admin/api/problem/delete/<int:pid>', methods=['POST'])
@admin_required
def admin_delete_problem(pid):
    p = Problem.query.get_or_404(pid)
    db.session.delete(p)
    db.session.commit()
    return jsonify({'ok': True})

@app.route('/admin/api/user/toggle/<int:uid>', methods=['POST'])
@admin_required
def admin_toggle_user(uid):
    u = User.query.get_or_404(uid)
    if u.role == 'admin':
        return jsonify({'ok': False, 'msg': '不能禁用管理员'})
    u.is_active = not u.is_active
    db.session.commit()
    return jsonify({'ok': True, 'active': u.is_active})

@app.route('/admin/api/user/reset_pwd/<int:uid>', methods=['POST'])
@admin_required
def admin_reset_pwd(uid):
    u = User.query.get_or_404(uid)
    new_pwd = request.get_json().get('password', '123456')
    u.set_password(new_pwd)
    db.session.commit()
    return jsonify({'ok': True})

@app.route('/admin/api/user/set_role/<int:uid>', methods=['POST'])
@admin_required
def admin_set_role(uid):
    u = User.query.get_or_404(uid)
    if u.id == session['user_id']:
        return jsonify({'ok': False, 'msg': '不能修改自己的角色'})
    data = request.get_json() or {}
    u.role = data.get('role', 'student')
    db.session.commit()
    return jsonify({'ok': True})

@app.route('/admin/api/contest/add', methods=['POST'])
@admin_required
def admin_add_contest():
    data = request.get_json() or {}
    if not data.get('title'):
        return jsonify({'ok': False, 'msg': '比赛标题不能为空'})
    c = Contest(
        title=data['title'], description=data.get('description',''),
        problems_json=json.dumps(data.get('problem_ids',[])),
        start_time=data.get('start_time',''), end_time=data.get('end_time',''),
        is_public=data.get('is_public', True), created_by=session['user_id'],
        created_at=now_str()
    )
    db.session.add(c)
    db.session.commit()
    return jsonify({'ok': True, 'id': c.id})

@app.route('/admin/api/contest/delete/<int:cid>', methods=['POST'])
@admin_required
def admin_delete_contest(cid):
    c = Contest.query.get_or_404(cid)
    db.session.delete(c)
    db.session.commit()
    return jsonify({'ok': True})

# ========== 个人设置 ==========
@app.route('/settings')
@login_required
def settings():
    user = User.query.get(session['user_id'])
    return render_template('settings.html', user=user)

@app.route('/api/settings/password', methods=['POST'])
@login_required
def change_password():
    user = User.query.get(session['user_id'])
    old = request.form.get('old_password', '')
    new = request.form.get('new_password', '')
    if not user.check_password(old):
        return jsonify({'ok': False, 'msg': '旧密码错误'})
    if len(new) < 4:
        return jsonify({'ok': False, 'msg': '新密码至少4位'})
    user.set_password(new)
    db.session.commit()
    return jsonify({'ok': True, 'msg': '密码修改成功'})

@app.route('/api/settings/nickname', methods=['POST'])
@login_required
def change_nickname():
    user = User.query.get(session['user_id'])
    nk = request.form.get('nickname', '').strip()
    if not nk or len(nk) > 20:
        return jsonify({'ok': False, 'msg': '昵称长度1-20'})
    user.nickname = nk
    db.session.commit()
    return jsonify({'ok': True, 'msg': '昵称修改成功'})

# ========== 启动 ==========
if __name__ == '__main__':
    with app.app_context():
        init_data()
    print('\n' + '='*50)
    print('  CodeMaster OJ 已启动!')
    print(f'  管理员账号: admin / admin123')
    print('  访问地址: http://localhost:5000')
    print('='*50 + '\n')
    app.run(host='0.0.0.0', port=5000, debug=True)

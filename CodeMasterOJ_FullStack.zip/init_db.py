#!/usr/bin/env python3
"""
CodeMaster OJ - 数据库初始化脚本
导入默认题目数据
"""

from app import app, db
from models import Problem, User, Contest
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta

def init_database():
    with app.app_context():
        # 创建所有表
        db.create_all()
        
        # 检查是否已有数据
        if Problem.query.first():
            print("数据库已有数据，跳过初始化")
            return
        
        # 创建管理员账号
        admin = User(
            username='admin',
            email='admin@codemaster.com',
            password_hash=generate_password_hash('admin123'),
            is_admin=True,
            solved_count=0,
            rating=3000
        )
        db.session.add(admin)
        
        # 创建测试用户
        test_user = User(
            username='test',
            email='test@example.com',
            password_hash=generate_password_hash('test123'),
            is_admin=False,
            solved_count=0,
            rating=1500
        )
        db.session.add(test_user)
        
        # 默认题目数据
        default_problems = [
            {
                'title': 'A+B 问题',
                'difficulty': '入门',
                'tags': '基础,数学',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>计算两个整数的和。</p>
<h4>输入格式</h4>
<p>一行两个整数 a 和 b。</p>
<h4>输出格式</h4>
<p>一个整数，表示 a+b 的结果。</p>
<h4>样例</h4>
<pre><code>输入: 1 2
输出: 3</code></pre>
<h4>数据范围</h4>
<p>-10^9 ≤ a, b ≤ 10^9</p>
                ''',
                'input_format': '一行两个整数 a 和 b',
                'output_format': '一个整数，表示 a+b 的结果',
                'sample_input': '1 2',
                'sample_output': '3',
                'hint': '使用 input() 读取输入，print() 输出结果',
                'test_cases': [
                    {'input': '1 2', 'output': '3'},
                    {'input': '5 7', 'output': '12'},
                    {'input': '-3 8', 'output': '5'},
                    {'input': '0 0', 'output': '0'},
                    {'input': '1000000 2000000', 'output': '3000000'}
                ]
            },
            {
                'title': '判断闰年',
                'difficulty': '入门',
                'tags': '基础,条件判断',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>判断给定年份是否为闰年。</p>
<p>闰年规则：</p>
<ul>
<li>能被4整除但不能被100整除，或者能被400整除</li>
</ul>
<h4>输入格式</h4>
<p>一个整数，表示年份。</p>
<h4>输出格式</h4>
<p>如果是闰年输出 "Yes"，否则输出 "No"。</p>
<h4>样例</h4>
<pre><code>输入: 2000
输出: Yes</code></pre>
                ''',
                'input_format': '一个整数，表示年份',
                'output_format': '如果是闰年输出 "Yes"，否则输出 "No"',
                'sample_input': '2000',
                'sample_output': 'Yes',
                'hint': '使用 % 取模运算符判断整除',
                'test_cases': [
                    {'input': '2000', 'output': 'Yes'},
                    {'input': '1900', 'output': 'No'},
                    {'input': '2024', 'output': 'Yes'},
                    {'input': '2023', 'output': 'No'},
                    {'input': '2400', 'output': 'Yes'}
                ]
            },
            {
                'title': '求最大值',
                'difficulty': '入门',
                'tags': '基础,数组',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>给定 n 个整数，找出其中的最大值。</p>
<h4>输入格式</h4>
<p>第一行一个整数 n (1 ≤ n ≤ 1000)</p>
<p>第二行 n 个整数</p>
<h4>输出格式</h4>
<p>一个整数，表示最大值。</p>
<h4>样例</h4>
<pre><code>输入: 
5
3 1 4 1 5
输出: 5</code></pre>
                ''',
                'input_format': '第一行 n，第二行 n 个整数',
                'output_format': '一个整数，表示最大值',
                'sample_input': '5\n3 1 4 1 5',
                'sample_output': '5',
                'hint': '使用 max() 函数或遍历比较',
                'test_cases': [
                    {'input': '5\n3 1 4 1 5', 'output': '5'},
                    {'input': '3\n-1 -2 -3', 'output': '-1'},
                    {'input': '1\n100', 'output': '100'},
                    {'input': '4\n0 0 0 0', 'output': '0'},
                    {'input': '6\n10 20 30 40 50 60', 'output': '60'}
                ]
            },
            {
                'title': '斐波那契数列',
                'difficulty': '简单',
                'tags': '数论,递归,动态规划',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>求斐波那契数列的第 n 项。</p>
<p>F(1) = 1, F(2) = 1, F(n) = F(n-1) + F(n-2)</p>
<h4>输入格式</h4>
<p>一个整数 n (1 ≤ n ≤ 30)</p>
<h4>输出格式</h4>
<p>第 n 个斐波那契数。</p>
<h4>样例</h4>
<pre><code>输入: 6
输出: 8</code></pre>
                ''',
                'input_format': '一个整数 n',
                'output_format': '第 n 个斐波那契数',
                'sample_input': '6',
                'sample_output': '8',
                'hint': '可以使用循环或递归，注意递归深度',
                'test_cases': [
                    {'input': '1', 'output': '1'},
                    {'input': '2', 'output': '1'},
                    {'input': '6', 'output': '8'},
                    {'input': '10', 'output': '55'},
                    {'input': '20', 'output': '6765'}
                ]
            },
            {
                'title': '判断素数',
                'difficulty': '简单',
                'tags': '数论,数学',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>判断一个正整数是否为素数。</p>
<p>素数是大于1的自然数，除了1和它本身外没有其他因数。</p>
<h4>输入格式</h4>
<p>一个正整数 n (2 ≤ n ≤ 10^6)</p>
<h4>输出格式</h4>
<p>是素数输出 "Yes"，否则输出 "No"。</p>
<h4>样例</h4>
<pre><code>输入: 17
输出: Yes</code></pre>
                ''',
                'input_format': '一个正整数 n',
                'output_format': '"Yes" 或 "No"',
                'sample_input': '17',
                'sample_output': 'Yes',
                'hint': '只需检查到 sqrt(n) 即可',
                'test_cases': [
                    {'input': '2', 'output': 'Yes'},
                    {'input': '17', 'output': 'Yes'},
                    {'input': '18', 'output': 'No'},
                    {'input': '97', 'output': 'Yes'},
                    {'input': '100', 'output': 'No'}
                ]
            },
            {
                'title': '字符串反转',
                'difficulty': '简单',
                'tags': '字符串',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>将输入的字符串反转输出。</p>
<h4>输入格式</h4>
<p>一个字符串（不含空格）</p>
<h4>输出格式</h4>
<p>反转后的字符串。</p>
<h4>样例</h4>
<pre><code>输入: Hello
输出: olleH</code></pre>
                ''',
                'input_format': '一个字符串',
                'output_format': '反转后的字符串',
                'sample_input': 'Hello',
                'sample_output': 'olleH',
                'hint': '使用字符串切片 [::-1]',
                'test_cases': [
                    {'input': 'Hello', 'output': 'olleH'},
                    {'input': 'Python', 'output': 'nohtyP'},
                    {'input': 'a', 'output': 'a'},
                    {'input': '12345', 'output': '54321'},
                    {'input': 'ABCdef', 'output': 'fedCBA'}
                ]
            },
            {
                'title': '阶乘计算',
                'difficulty': '简单',
                'tags': '数学',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>计算 n 的阶乘。</p>
<p>n! = 1 × 2 × 3 × ... × n</p>
<h4>输入格式</h4>
<p>一个整数 n (0 ≤ n ≤ 12)</p>
<h4>输出格式</h4>
<p>n 的阶乘。</p>
<h4>样例</h4>
<pre><code>输入: 5
输出: 120</code></pre>
                ''',
                'input_format': '一个整数 n',
                'output_format': 'n 的阶乘',
                'sample_input': '5',
                'sample_output': '120',
                'hint': '使用循环累乘',
                'test_cases': [
                    {'input': '0', 'output': '1'},
                    {'input': '1', 'output': '1'},
                    {'input': '5', 'output': '120'},
                    {'input': '10', 'output': '3628800'},
                    {'input': '12', 'output': '479001600'}
                ]
            },
            {
                'title': '冒泡排序',
                'difficulty': '中等',
                'tags': '排序,算法',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>对 n 个整数进行冒泡排序。</p>
<h4>输入格式</h4>
<p>第一行一个整数 n (1 ≤ n ≤ 100)</p>
<p>第二行 n 个整数</p>
<h4>输出格式</h4>
<p>一行 n 个整数，表示排序后的结果。</p>
<h4>样例</h4>
<pre><code>输入:
5
5 2 8 1 9
输出:
1 2 5 8 9</code></pre>
                ''',
                'input_format': '第一行 n，第二行 n 个整数',
                'output_format': '排序后的 n 个整数',
                'sample_input': '5\n5 2 8 1 9',
                'sample_output': '1 2 5 8 9',
                'hint': '使用双重循环，相邻元素比较交换',
                'test_cases': [
                    {'input': '5\n5 2 8 1 9', 'output': '1 2 5 8 9'},
                    {'input': '3\n3 2 1', 'output': '1 2 3'},
                    {'input': '1\n42', 'output': '42'},
                    {'input': '4\n-1 -5 0 3', 'output': '-5 -1 0 3'},
                    {'input': '6\n1 1 1 1 1 1', 'output': '1 1 1 1 1 1'}
                ]
            },
            {
                'title': '回文判断',
                'difficulty': '简单',
                'tags': '字符串',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>判断一个字符串是否为回文串。</p>
<p>回文串指正读反读都相同的字符串。</p>
<h4>输入格式</h4>
<p>一个字符串（不含空格）</p>
<h4>输出格式</h4>
<p>是回文输出 "Yes"，否则输出 "No"。</p>
<h4>样例</h4>
<pre><code>输入: level
输出: Yes</code></pre>
                ''',
                'input_format': '一个字符串',
                'output_format': '"Yes" 或 "No"',
                'sample_input': 'level',
                'sample_output': 'Yes',
                'hint': '比较字符串与其反转',
                'test_cases': [
                    {'input': 'level', 'output': 'Yes'},
                    {'input': 'hello', 'output': 'No'},
                    {'input': 'a', 'output': 'Yes'},
                    {'input': 'abba', 'output': 'Yes'},
                    {'input': 'abcba', 'output': 'Yes'}
                ]
            },
            {
                'title': '最大公约数',
                'difficulty': '简单',
                'tags': '数论,数学',
                'time_limit': 1000,
                'memory_limit': 128,
                'description': '''
<p>求两个正整数的最大公约数（GCD）。</p>
<h4>输入格式</h4>
<p>一行两个正整数 a 和 b。</p>
<h4>输出格式</h4>
<p>最大公约数。</p>
<h4>样例</h4>
<pre><code>输入: 12 18
输出: 6</code></pre>
                ''',
                'input_format': '一行两个正整数',
                'output_format': '最大公约数',
                'sample_input': '12 18',
                'sample_output': '6',
                'hint': '使用辗转相除法',
                'test_cases': [
                    {'input': '12 18', 'output': '6'},
                    {'input': '7 13', 'output': '1'},
                    {'input': '100 25', 'output': '25'},
                    {'input': '1 1', 'output': '1'},
                    {'input': '48 18', 'output': '6'}
                ]
            }
        ]
        
        # 添加题目到数据库
        for i, p in enumerate(default_problems, 1):
            problem = Problem(
                title=p['title'],
                difficulty=p['difficulty'],
                tags=p['tags'],
                time_limit=p['time_limit'],
                memory_limit=p['memory_limit'],
                description=p['description'],
                input_format=p['input_format'],
                output_format=p['output_format'],
                sample_input=p['sample_input'],
                sample_output=p['sample_output'],
                hint=p['hint'],
                test_cases=p['test_cases'],
                submit_count=0,
                accept_count=0
            )
            db.session.add(problem)
        
        # 创建一个示例比赛
        contest = Contest(
            title='新手入门赛',
            description='适合初学者的编程比赛，包含5道入门题目。',
            start_time=datetime.now(),
            end_time=datetime.now() + timedelta(days=7),
            problems='1,2,3,4,5',
            is_active=True
        )
        db.session.add(contest)
        
        db.session.commit()
        print("数据库初始化完成！")
        print(f"- 管理员账号: admin / admin123")
        print(f"- 测试账号: test / test123")
        print(f"- 导入题目: {len(default_problems)} 道")
        print(f"- 创建比赛: 1 个")

if __name__ == '__main__':
    init_database()

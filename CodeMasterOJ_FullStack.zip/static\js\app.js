// ===== Toast =====
function showToast(msg, type='success', dur=3000) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast toast-' + type + ' show';
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), dur);
}

// ===== Modal =====
function showModal(title, bodyHtml) {
  document.getElementById('modal-content').innerHTML = '<div class="modal-title">'+title+'</div>'+bodyHtml;
  document.getElementById('modal-overlay').style.display = 'flex';
}
function closeModal() { document.getElementById('modal-overlay').style.display = 'none'; }
document.addEventListener('keydown', e => { if(e.key==='Escape') closeModal(); });
document.getElementById('modal-overlay')?.addEventListener('click', e => { if(e.target===e.currentTarget) closeModal(); });

// ===== CodeMirror helper =====
let cmInstance = null;
function initCM(textareaId, code) {
  const ta = document.getElementById(textareaId);
  if (!ta) return null;
  if (cmInstance) { cmInstance.toTextArea(); cmInstance = null; }
  ta.value = code || '';
  if (typeof CodeMirror !== 'undefined') {
    cmInstance = CodeMirror.fromTextArea(ta, {
      mode: 'python', theme: 'eclipse', lineNumbers: true,
      indentUnit: 4, tabSize: 4, indentWithTabs: false,
      autoCloseBrackets: true, matchBrackets: true,
      extraKeys: { 'Tab': cm => cm.execCommand('indentMore'), 'Ctrl-Enter': () => document.getElementById('submit-btn')?.click() }
    });
    return cmInstance;
  }
  return null;
}
function getCMCode() {
  return cmInstance ? cmInstance.getValue() : (document.getElementById('code-textarea')?.value || '');
}

// ===== Judge =====
async function submitCode(probId) {
  const code = getCMCode();
  if (!code.trim()) return showToast('代码不能为空', 'error');
  const ra = document.getElementById('result-area');
  ra.innerHTML = '<div class="judge-header wa">⚙️ 评测中...</div>';
  const fd = new FormData();
  fd.append('problem_id', probId);
  fd.append('code', code);
  try {
    const res = await fetch('/api/submit', { method: 'POST', body: fd });
    const d = await res.json();
    if (!d.ok) return showToast(d.msg, 'error');
    renderJudgeResult(d, ra);
    if (d.status === 'AC') showToast('🎉 通过！+' + d.points + '分', 'success');
    else showToast('❌ 未通过 ' + d.passed + '/' + d.total, 'error');
  } catch(e) { showToast('网络错误', 'error'); ra.innerHTML = '<div class="judge-header wa">网络错误</div>'; }
}

async function runCustom() {
  const code = getCMCode();
  const inp = document.getElementById('custom-input')?.value || '';
  const ra = document.getElementById('result-area');
  ra.innerHTML = '<div class="judge-header">⚙️ 运行中...</div>';
  const fd = new FormData();
  fd.append('code', code);
  fd.append('input', inp);
  try {
    const res = await fetch('/api/run', { method: 'POST', body: fd });
    const d = await res.json();
    ra.innerHTML = '<div class="panel-header">运行结果</div><pre style="padding:12px;background:var(--bg);font-size:13px;white-space:pre-wrap">'+escHtml(d.stderr || d.stdout || '(无输出)')+'</pre>';
  } catch(e) { showToast('网络错误', 'error'); }
}

function renderJudgeResult(d, ra) {
  const ac = d.status === 'AC';
  let html = '<div class="judge-header '+(ac?'ac':'wa')+'">'+(ac?'🎉 通过！':'❌ 未通过')+' <span style="font-size:13px;color:var(--text2)">'+d.passed+'/'+d.total+' 测试点</span></div>';
  html += '<div class="result-area" style="border:none;padding:8px 0">';
  for (const r of d.results) {
    html += '<div class="case-row case-'+r.status+'"><span class="status-badge status-'+r.status+'">'+r.status+'</span> 测试点'+r.index;
    if (r.status !== 'AC') {
      html += '<div class="case-detail"><span>输入:</span><code>'+escHtml(r.input)+'</code><span>期望:</span><code>'+escHtml(r.expected)+'</code><span>实际:</span><code>'+escHtml(r.actual)+'</code></div>';
    }
    html += '</div>';
  }
  html += '</div>';
  ra.innerHTML = html;
}

// ===== Comment =====
async function postComment(probId) {
  const inp = document.getElementById('comment-input');
  if (!inp || !inp.value.trim()) return showToast('请输入评论', 'error');
  const fd = new FormData();
  fd.append('problem_id', probId);
  fd.append('content', inp.value.trim());
  try {
    const res = await fetch('/api/comment', { method: 'POST', body: fd });
    const d = await res.json();
    if (d.ok) { location.reload(); }
    else showToast(d.msg, 'error');
  } catch(e) { showToast('网络错误', 'error'); }
}

async function deleteComment(cid) {
  if (!confirm('确定删除该评论？')) return;
  try {
    const res = await fetch('/api/comment/delete/'+cid, { method: 'POST' });
    const d = await res.json();
    if (d.ok) location.reload();
  } catch(e) {}
}

// ===== Admin helpers =====
async function apiPost(url, data) {
  const res = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data) });
  return await res.json();
}

async function apiForm(url, fd) {
  const res = await fetch(url, { method:'POST', body:fd });
  return await res.json();
}

function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// ===== Settings =====
async function changePassword() {
  const fd = new FormData();
  fd.append('old_password', document.getElementById('old_pwd')?.value||'');
  fd.append('new_password', document.getElementById('new_pwd')?.value||'');
  const d = await apiForm('/api/settings/password', fd);
  showToast(d.msg, d.ok?'success':'error');
  if(d.ok) { document.getElementById('old_pwd').value=''; document.getElementById('new_pwd').value=''; }
}
async function changeNickname() {
  const fd = new FormData();
  fd.append('nickname', document.getElementById('nickname')?.value||'');
  const d = await apiForm('/api/settings/nickname', fd);
  showToast(d.msg, d.ok?'success':'error');
  if(d.ok) setTimeout(()=>location.reload(), 800);
}

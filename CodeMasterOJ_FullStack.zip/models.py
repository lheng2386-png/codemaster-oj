# -*- coding: utf-8 -*-
"""数据库模型"""
import sqlite3
import json
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    nickname = db.Column(db.String(80), default='')
    role = db.Column(db.String(20), default='student')  # admin / student
    points = db.Column(db.Integer, default=0)
    solved_count = db.Column(db.Integer, default=0)
    submit_count = db.Column(db.Integer, default=0)
    streak = db.Column(db.Integer, default=0)
    last_active = db.Column(db.String(20), default='')
    created_at = db.Column(db.String(30), default='')
    is_active = db.Column(db.Boolean, default=True)
    achievements = db.Column(db.Text, default='[]')  # JSON list

    def set_password(self, pwd):
        self.password_hash = generate_password_hash(pwd)

    def check_password(self, pwd):
        return check_password_hash(self.password_hash, pwd)

    def to_dict(self):
        return {
            'id': self.id, 'username': self.username, 'nickname': self.nickname or self.username,
            'role': self.role, 'points': self.points, 'solved_count': self.solved_count,
            'submit_count': self.submit_count, 'streak': self.streak,
            'achievements': json.loads(self.achievements or '[]'),
            'is_active': self.is_active, 'created_at': self.created_at
        }

    def get_level(self):
        levels = [
            (0,'萌新','#6B7280'), (30,'入门','#10B981'), (80,'熟练','#3B82F6'),
            (150,'进阶','#8B5CF6'), (280,'高手','#F59E0B'), (450,'大师','#EF4444'),
            (650,'宗师','#EC4899'), (900,'传说','#F59E0B')
        ]
        lv = levels[0]
        for l in levels:
            if self.points >= l[0]: lv = l
        return lv


class Problem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    difficulty = db.Column(db.String(20), default='入门')
    category = db.Column(db.String(50), default='基础')
    tags = db.Column(db.Text, default='[]')
    description = db.Column(db.Text, default='')
    template = db.Column(db.Text, default='')
    solution = db.Column(db.Text, default='')
    hint = db.Column(db.Text, default='')
    cases_json = db.Column(db.Text, default='[]')  # JSON: [[input, output], ...]
    points = db.Column(db.Integer, default=10)
    time_limit = db.Column(db.Integer, default=5)  # 秒
    memory_limit = db.Column(db.Integer, default=256)  # MB
    ac_count = db.Column(db.Integer, default=0)
    submit_count = db.Column(db.Integer, default=0)
    is_public = db.Column(db.Boolean, default=True)
    author_id = db.Column(db.Integer, default=0)
    created_at = db.Column(db.String(30), default='')

    @property
    def cases(self):
        return json.loads(self.cases_json or '[]')

    @cases.setter
    def cases(self, val):
        self.cases_json = json.dumps(val, ensure_ascii=False)

    @property
    def tag_list(self):
        return json.loads(self.tags or '[]')

    @tag_list.setter
    def tag_list(self, val):
        self.tags = json.dumps(val, ensure_ascii=False)

    def to_dict(self, brief=False):
        d = {
            'id': self.id, 'title': self.title, 'difficulty': self.difficulty,
            'category': self.category, 'tags': self.tag_list, 'points': self.points,
            'ac_count': self.ac_count, 'submit_count': self.submit_count,
        }
        if not brief:
            d.update({
                'description': self.description, 'template': self.template,
                'hint': self.hint, 'time_limit': self.time_limit,
            })
        return d


class Submission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    problem_id = db.Column(db.Integer, nullable=False)
    code = db.Column(db.Text, default='')
    status = db.Column(db.String(10), default='')  # AC / WA / RE / TLE / CE
    passed = db.Column(db.Integer, default=0)
    total = db.Column(db.Integer, default=0)
    details = db.Column(db.Text, default='[]')  # JSON
    created_at = db.Column(db.String(30), default='')

    def to_dict(self):
        return {
            'id': self.id, 'user_id': self.user_id, 'problem_id': self.problem_id,
            'code': self.code, 'status': self.status, 'passed': self.passed,
            'total': self.total, 'created_at': self.created_at,
        }


class Contest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, default='')
    problems_json = db.Column(db.Text, default='[]')  # problem IDs
    start_time = db.Column(db.String(30), default='')
    end_time = db.Column(db.String(30), default='')
    is_public = db.Column(db.Boolean, default=True)
    created_by = db.Column(db.Integer, default=0)
    created_at = db.Column(db.String(30), default='')

    @property
    def problem_ids(self):
        return json.loads(self.problems_json or '[]')

    @problem_ids.setter
    def problem_ids(self, val):
        self.problems_json = json.dumps(val)

    def to_dict(self):
        return {
            'id': self.id, 'title': self.title, 'description': self.description,
            'problem_ids': self.problem_ids, 'start_time': self.start_time,
            'end_time': self.end_time, 'is_public': self.is_public,
            'created_by': self.created_by, 'created_at': self.created_at,
        }


class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    problem_id = db.Column(db.Integer, nullable=False)
    content = db.Column(db.Text, default='')
    created_at = db.Column(db.String(30), default='')

    def to_dict(self, username=''):
        return {
            'id': self.id, 'user_id': self.user_id, 'username': username,
            'problem_id': self.problem_id, 'content': self.content,
            'created_at': self.created_at,
        }

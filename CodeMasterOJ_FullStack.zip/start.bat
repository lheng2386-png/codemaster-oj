:
@echo off
chcp 65001 >nul
echo =========================================
echo   CodeMaster OJ 启动脚本
echo =========================================
echo.

:: 检查 Python
python --version >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到 Python，请确保 Python 已安装并添加到 PATH
    pause
    exit /b 1
)

:: 安装依赖
echo [1/3] 检查依赖...
if not exist "venv" (
    echo 创建虚拟环境...
    python -m venv venv
)
call venv\Scripts\activate.bat
pip install -q -r requirements.txt

:: 启动
echo [2/3] 启动服务器...
echo [3/3] 访问地址: http://localhost:5000
echo.
echo 管理员账号: admin / admin123
echo.
python app.py

pause

# CodeMaster OJ - 程序设计教学评测平台

## 项目结构
```
oj_fullstack/
├── app.py              # Flask 主程序
├── models.py           # 数据库模型
├── judge.py            # 代码判题引擎
├── requirements.txt    # Python 依赖
├── start.bat           # Windows 一键启动
├── templates/          # HTML 模板
│   ├── base.html
│   ├── login.html
│   ├── register.html
│   ├── index.html
│   ├── problems.html
│   ├── problem.html
│   ├── ranking.html
│   ├── contest.html
│   ├── contest_detail.html
│   ├── settings.html
│   └── admin.html
└── static/
    ├── css/style.css
    └── js/app.js
```

## 功能特性

### 学生端
- ✅ 用户注册/登录
- ✅ 题库浏览（20道精选题目）
- ✅ 代码编辑器（CodeMirror，语法高亮）
- ✅ 在线评测（Python 3 代码在服务器端沙箱执行）
- ✅ 题目评论区（讨论交流）
- ✅ 排行榜（积分排名）
- ✅ 比赛系统
- ✅ 个人设置（修改昵称、密码）

### 管理员端
- ✅ 题目管理（添加/删除题目，设置测试用例）
- ✅ 学生管理（查看账号、重置密码、禁用/启用）
- ✅ 比赛管理（创建比赛、选择题目）
- ✅ 题解查看（仅管理员可见参考答案）

## 快速启动

### Windows
双击 `start.bat` 即可启动

### 手动启动
```bash
pip install -r requirements.txt
python app.py
```

然后访问 http://localhost:5000

## 默认账号
- 管理员：`admin` / `admin123`

## 技术栈
- 后端：Flask + SQLite + SQLAlchemy
- 前端：原生 HTML + CSS + JS + CodeMirror
- 判题：Python subprocess 沙箱执行

# -*- coding: utf-8 -*-
"""Python 代码判题引擎（服务器端沙箱执行）"""
import subprocess
import tempfile
import os
import sys
import signal
import json
import traceback

def judge_python(code, cases, time_limit=5, memory_limit=256):
    """
    在子进程中运行 Python 代码并判题
    cases: [[input_str, expected_output], ...]
    返回: {results: [...], passed: int, total: int}
    """
    results = []
    passed = 0

    for i, (inp, expected) in enumerate(cases):
        inp = str(inp)
        expected = str(expected).strip()
        case_result = {
            'index': i + 1,
            'input': inp,
            'expected': expected,
            'actual': '',
            'status': '',
            'msg': '',
        }

        try:
            # 写入临时文件
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
                f.write(code)
                code_file = f.name

            try:
                proc = subprocess.run(
                    [sys.executable, code_file],
                    input=inp,
                    capture_output=True,
                    text=True,
                    timeout=time_limit,
                    encoding='utf-8',
                    errors='replace',
                )
                actual = proc.stdout.strip()
                case_result['actual'] = actual

                if proc.returncode != 0:
                    stderr = proc.stderr.strip()
                    if 'Traceback' in stderr or 'Error' in stderr:
                        case_result['status'] = 'RE'
                        case_result['msg'] = stderr[:500]
                    else:
                        case_result['status'] = 'RE'
                        case_result['msg'] = stderr[:500] or '运行错误'
                elif actual == expected:
                    case_result['status'] = 'AC'
                    case_result['msg'] = '通过'
                    passed += 1
                else:
                    case_result['status'] = 'WA'
                    case_result['msg'] = '答案错误'
            except subprocess.TimeoutExpired:
                case_result['status'] = 'TLE'
                case_result['msg'] = f'运行超时（{time_limit}秒）'
            except Exception as e:
                case_result['status'] = 'RE'
                case_result['msg'] = str(e)[:500]
            finally:
                os.unlink(code_file)

        except Exception as e:
            case_result['status'] = 'RE'
            case_result['msg'] = f'系统错误: {str(e)[:200]}'

        results.append(case_result)

    return {
        'results': results,
        'passed': passed,
        'total': len(cases),
    }


def test_code(code, input_data, time_limit=5):
    """仅运行代码，返回输出（自定义测试）"""
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
            f.write(code)
            code_file = f.name

        try:
            proc = subprocess.run(
                [sys.executable, code_file],
                input=input_data,
                capture_output=True,
                text=True,
                timeout=time_limit,
                encoding='utf-8',
                errors='replace',
            )
            return {
                'stdout': proc.stdout,
                'stderr': proc.stderr,
                'returncode': proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {'stdout': '', 'stderr': f'运行超时（{time_limit}秒）', 'returncode': -1}
        except Exception as e:
            return {'stdout': '', 'stderr': str(e), 'returncode': -1}
        finally:
            os.unlink(code_file)
    except Exception as e:
        return {'stdout': '', 'stderr': str(e), 'returncode': -1}
